var escreve_p = function(paragrafo){
    document.write('<p>' + paragrafo+'</p>');
};